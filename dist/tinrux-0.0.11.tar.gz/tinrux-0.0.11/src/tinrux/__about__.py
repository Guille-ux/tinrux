# SPDX-FileCopyrightText: 2025-present Guillermo Leira Temes <guilleleiratemes@gmail.com>
#
# SPDX-License-Identifier: GPLv3
__version__ = "0.0.11"
