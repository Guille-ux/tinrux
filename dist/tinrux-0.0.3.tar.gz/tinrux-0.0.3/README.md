# tinrux

[![PyPI - Version](https://img.shields.io/pypi/v/tinrux.svg)](https://pypi.org/project/tinrux)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tinrux.svg)](https://pypi.org/project/tinrux)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install tinrux
```

## License

`tinrux` is distributed under the terms of the [GPLv3](https://spdx.org/licenses/GPL-3.0-or-later.html) license.
